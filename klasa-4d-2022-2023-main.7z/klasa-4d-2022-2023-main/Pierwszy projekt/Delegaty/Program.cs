﻿using System;

namespace Delegaty
{
    class Program
    {
        static void Main(string[] args)
        {
            Delegaty delegaty = new Delegaty();
            delegaty.TestDelegat();


            Console.ReadLine();
        }
    }
}
