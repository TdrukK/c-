﻿using System;

namespace Kolekcje
{
    class Program
    {
        static void Main(string[] args)
        {
            TestKolekcji testKolekcji = new TestKolekcji();
            //testKolekcji.TestTablic();
            //testKolekcji.Test_tablic_z_obiektami();
            //testKolekcji.TestListy_int();
            //testKolekcji.Test_listy();
            //testKolekcji.TestListy_int();
            //testKolekcji.Test_Nazwa_Techniczna();
            testKolekcji.Linq();

        }
    }
}
