﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektUczniowie.Baza_danych.Model
{
    public class Klasa
    {
        public int Id { get; set; }
        public string NazwaKlasy { get; set; }
    }
}
