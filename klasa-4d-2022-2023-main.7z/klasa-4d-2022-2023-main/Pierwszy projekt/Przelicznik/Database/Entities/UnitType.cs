﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Przelicznik.Database.Entities
{
    class UnitType
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
