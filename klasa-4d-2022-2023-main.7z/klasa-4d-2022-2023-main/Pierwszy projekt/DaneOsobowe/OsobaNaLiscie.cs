﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DaneOsobowe
{
    class OsobaNaLiscie
    {
        public string Imie { get; set; }
        public string Nazwisko { get; set; }
        public int Wiek { get; set; }
        public bool Pelnoletnosc { get; set; }
        public string Miasto { get; set; }
        public string Ulica { get; set; }
    }
}
