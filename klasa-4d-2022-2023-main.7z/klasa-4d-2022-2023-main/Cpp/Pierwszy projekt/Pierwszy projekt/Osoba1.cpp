#pragma once
//#include "Nag��wek.h"

//namespace wersja1
//{
//	void funkcja2()
//	{
//
//	}
//
//	//int xde;
//
//}