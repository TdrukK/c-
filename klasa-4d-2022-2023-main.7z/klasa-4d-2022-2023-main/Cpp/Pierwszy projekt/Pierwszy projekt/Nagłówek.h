#pragma once

//#include "Osoba1.cpp"

//namespace wersja1
//{
//	//void funkcja();
//}
